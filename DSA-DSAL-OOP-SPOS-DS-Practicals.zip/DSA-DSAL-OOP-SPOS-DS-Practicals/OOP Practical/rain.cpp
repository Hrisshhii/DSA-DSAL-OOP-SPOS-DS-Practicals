#include <iostream>
#include <math.h>
#include<direct.h>
#include<conio.h>
#include<stdlib.h>
#include <graphics.h>
using namespace std;

class walkingman
{
    int rhx,rhy;
    public:
    void draw(int x,int y)
    {
        int j;
        rhx=x;
        rhy=y;
        for(j=0;j<100;j++)
        {
            char msg[]="|";
            outtextxy(rand()%rhx,rand()%(rhy-50),msg);
            setcolor(WHITE);
        }
    }
    void draw(int i)
    {
        line(20,280,580,380);
        if(i%2)
        {
            line(25+i,380,35+i,340);
            line(45+i,380,35+i,340);
            line(35+i,310,25+i,330);
            delay(20);
        }
        else
        {
            line(35+i,340,35+1,310);
            line(35+i,310,40+i,330);
            delay(20);
        }
        line(35+i,340,35+i,310);
        circle(35+i,300,10);
        line(35+i,310,50+i,330);
        line(50+i,330,50+i,280);
        line(15+i,280,85+i,280);
        arc(50+i,280,0,180,35);
        arc(55+i,330,180,360,5);
    }
};

int main()
{
    int gd=DETECT,gm;
    int rhx,rhy,j,i;
    walkingman w;
    initgraph(&gd,&gm,NULL);
    for(i=0;i<500;i++)
    {
        w.draw(i);
        rhx=getmaxx();
        rhy=getmaxy();
        w.draw(rhx,rhy);
        delay(150);
        cleardevice();
    }
    getch();
    closegraph();
    return 0;
}