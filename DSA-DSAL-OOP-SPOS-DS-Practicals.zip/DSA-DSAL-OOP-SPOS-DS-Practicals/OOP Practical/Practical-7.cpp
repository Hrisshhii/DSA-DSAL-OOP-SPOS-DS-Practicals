#include<iostream>
#include<map>
#include<algorithm>
using namespace std;

string uppercase(string str) {
    transform(str.begin(), str.end(), str.begin(), ::toupper);
    return str;
}
int main()
{
    int choice;
    string element;
    map<string,int> state;
    state["GUJRAT"]=590;
    state["GOA"]=450;
    state["MADHYA PRADESH: "]=250;
    state["TAMIL NADU"]=180;
    state["KARNATAKA"]=290;
    state["KERLA"]=130;
    state["HARYANA"]=350;
    state["BIHAR"]=420;
    state.insert({"MAHARASHTRA",780});
    do{
        cout<<"\n***************MENU***************\n1.SEARCHING THE POPULATION OF A PARTICULAR STATE\n2.PRINT THE WHOLE MAP\n3.CHANGE POPULATION OF A STATE\n4.ADD NEW STATE\n5.EXIT\n"<<endl;
        cout<<"ENTER YOUR CHOICE: "<<endl;
        cin>>choice;
        switch(choice)
        {
            case 1:
            {
                cin.ignore();
                cout<<"ENTER THE NAME OF STATE TO CHECK POPULATION OF: "<<endl;
                getline(cin,element);
                element=uppercase(element);
                if(state.find(element)!=state.end()){
                    cout<<"\n\nPopulation of "<<element<<" is"<<state[element]<<" MILLION\n\n"<<endl;
                }
                else
                {
                    cout<<"\n\nSTATE "<<element<<" NOT IN DATA BASE: \n\n"<<endl;
                }
                break;
            }
            case 2:
            {
                map<string,int>::iterator it;
                for(it=state.begin();it!=state.end();it++)
                {
                    cout << "STATE: " << it->first << ", POPULATION: " << it->second << " MILLION" << endl;
                }
                break;
            }
            case 3:
            {
                cin.ignore();
                int pop;
                cout << "ENTER THE NAME OF THE STATE TO MODIFY POPULATION: " << endl;
                getline(cin,element);
                element=uppercase(element);
                if(state.find(element)!=state.end())
                {
                    cout<<"ENTER NEW POPULATION: "<<endl;
                    cin>>pop;
                    state[element]=pop;
                    cout<<"\n\nUPDATED SUCCCESSFULLY!!!\n\n"<<endl;
                }
                else{
                    cout<<"STATE NOT FOUND!!!!"<<endl;
                }
                break;
            }
            case 4:
            {
                string s;
                int pop;
                cin.ignore();
                cout<<"ENTER THE NAME OF THE STATE YOU WANT TO ADD TO THE MAP: "<<endl;
                getline(cin,s);
                s=uppercase(s);
                cout<<"ENTER THE POPULATION: "<<endl;
                cin>>pop;
                state[s]=pop;
                cout<<"Population of "<<s<<"i.e"<<pop<<" MILLION is added to the Database!!"<<endl;
                break;
            }
            case 5:
            {
                cout<<"\nEXITING................:)\n"<<endl;
                break;
            }
            default:
            {
                cout<<"INVALID CHOICE!!"<<endl;
                break;
            }
        }
    }while(choice!=5);
    return 0;
}
