#include <iostream>
#include <cmath>
#include <graphics.h>
#define MAX 10

using namespace std;

class Transformation {
public:
    int matrix[3][MAX]; // Holds coordinates (x, y, 1)
    int n;              // Number of vertices

    Transformation(int num_vertices = 0) : n(num_vertices) {
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < MAX; j++)
                matrix[i][j] = 0;
    }

    void inputVertices() {
        cout << "ENTER THE NUMBER OF VERTEX IN SEQUENCE: " << endl;
        cin >> n;
        for (int i = 0; i < n; i++) {
            cout << "ENTER COORDINATES (x, y): " << endl;
            cin >> matrix[0][i] >> matrix[1][i];
            matrix[2][i] = 1;
        }
    }

    void draw(int color) {
        setcolor(color);
        for (int i = 0; i < n - 1; i++) {
            line(matrix[0][i], matrix[1][i], matrix[0][i + 1], matrix[1][i + 1]);
        }
        line(matrix[0][n - 1], matrix[1][n - 1], matrix[0][0], matrix[1][0]);
    }

    Transformation operator*(const float m[3][3]) {
        Transformation result(n);
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < 3; j++) {
                result.matrix[j][i] = 0;
                for (int k = 0; k < 3; k++) {
                    result.matrix[j][i] += m[j][k] * matrix[k][i];
                }
            }
        }
        return result;
    }

    void operator=(const Transformation &t) {
        n = t.n;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = t.matrix[i][j];
            }
        }
    }
};

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, NULL);

    Transformation shape;
    shape.inputVertices();

    shape.draw(RED);

    int choice;
    do {
        cout << "\n\nMENU\n1. Translate\n2. Scaling\n3. Rotation\n4. EXIT" << endl;
        cout << "ENTER YOUR CHOICE: " << endl;
        cin >> choice;

        switch (choice) {
        case 1: { // Translation
            int tx, ty;
            cout << "ENTER THE TRANSLATION VALUES (tx, ty): " << endl;
            cin >> tx >> ty;

            float translationMatrix[3][3] = {
                {1, 0, tx},
                {0, 1, ty},
                {0, 0, 1}
            };

            Transformation translatedShape = shape * translationMatrix;
            translatedShape.draw(BLUE);
            break;
        }

        case 2: { // Scaling
            float sx, sy;
            cout << "ENTER THE SCALING FACTORS (sx, sy): " << endl;
            cin >> sx >> sy;

            float scalingMatrix[3][3] = {
                {sx, 0, 0},
                {0, sy, 0},
                {0, 0, 1}
            };

            Transformation scaledShape = shape * scalingMatrix;
            scaledShape.draw(GREEN);
            break;
        }

        case 3: { // Rotation
            float angle;
            cout << "ENTER THE ROTATION ANGLE (in degrees): " << endl;
            cin >> angle;

            float rad = angle * M_PI / 180.0;
            float rotationMatrix[3][3] = {
                {cos(rad), -sin(rad), 0},
                {sin(rad), cos(rad), 0},
                {0, 0, 1}
            };

            Transformation rotatedShape = shape * rotationMatrix;
            rotatedShape.draw(YELLOW);
            break;
        }

        case 4:
            cout << "EXITING... :)" << endl;
            break;

        default:
            cout << "INCORRECT ENTRY!!!" << endl;
            break;
        }
    } while (choice != 4);

    getch();
    closegraph();
    return 0;
}
