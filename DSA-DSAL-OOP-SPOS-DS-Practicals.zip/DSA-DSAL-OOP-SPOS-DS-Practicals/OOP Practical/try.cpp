#include <iostream>
#include <graphics.h>
using namespace std;

struct edge {
    int x1, y1, x2, y2;
    float slope;
};

int main() {
    int gd = DETECT, gm, n, i, j, k, temp;
    struct edge ed[10], active[10];
    int x[10], y[10], ymax = 0, ymin = 480, yy;
    float dx, dy, inter_x[10];

    initgraph(&gd, &gm, NULL);
    cout << "ENTER THE NO OF VERTICES: " << endl;
    cin >> n;
    cout << "ENTER VERTICES: " << endl;

    // Input the vertices of the polygon
    for(i = 0; i < n; i++) {
        cin >> x[i] >> y[i];
        if(y[i] > ymax) ymax = y[i];
        if(y[i] < ymin) ymin = y[i];
        ed[i].x1 = x[i];
        ed[i].y1 = y[i];
    }

    cout << "EDGE INFORMATION!!! " << endl;
    for(i = 0; i < n - 1; i++) {
        ed[i].x2 = ed[i + 1].x1;
        ed[i].y2 = ed[i + 1].y1;
        cout << "(" << ed[i].x1 << "," << ed[i].y1 << ") (" << ed[i].x2 << "," << ed[i].y2 << ")" << endl;
    }
    ed[i].x2 = ed[0].x1;
    ed[i].y2 = ed[0].y1;
    cout << "(" << ed[i].x1 << "," << ed[i].y1 << ") (" << ed[i].x2 << "," << ed[i].y2 << ")" << endl;

    // Sort edges so that y1 < y2 for each edge
    for(i = 0; i < n; i++) {
        if(ed[i].y1 > ed[i].y2) {
            temp = ed[i].y1;
            ed[i].y1 = ed[i].y2;
            ed[i].y2 = temp;
            temp = ed[i].x1;
            ed[i].x1 = ed[i].x2;
            ed[i].x2 = temp;
        }
    }

    // Draw the edges of the polygon
    for(i = 0; i < n; i++) {
        line(ed[i].x1, ed[i].y1, ed[i].x2, ed[i].y2);
    }

    // Calculate slopes for each edge
    for(i = 0; i < n; i++) {
        dx = ed[i].x2 - ed[i].x1;
        dy = ed[i].y2 - ed[i].y1;
        if(dy == 0)
            ed[i].slope = 0;
        else
            ed[i].slope = dx / dy;
    }

    // Initialize active edges list
    for(i = 0; i < n; i++) {
        if(ed[i].y1 < ymax) {
            active[i] = ed[i];
        }
    }

    yy = ymax;
    while(yy > ymin) {
        j = 0; // For counting active edges
        for(i = 0; i < n; i++) {
            if(ed[i].y1 <= yy && ed[i].y2 >= yy) {
                // Calculate the intersection point with the scanline
                inter_x[j] = ed[i].x1 + (yy - ed[i].y1) * ed[i].slope;
                j++;
            }
        }

        // Sort the intersection points
        for(i = 0; i < j - 1; i++) {
            for(k = 0; k < j - i - 1; k++) {
                if(inter_x[k] > inter_x[k + 1]) {
                    temp = (int)inter_x[k];
                    inter_x[k] = inter_x[k + 1];
                    inter_x[k + 1] = temp;
                }
            }
        }

        // Draw the lines between pairs of intersection points
        for(i = 0; i < j; i += 2) {
            setcolor(GREEN);
            line((int)inter_x[i], yy, (int)inter_x[i + 1], yy);
        }

        yy--;
        delay(50);
    }

    delay(10000);
    closegraph();
    return 0;
}
